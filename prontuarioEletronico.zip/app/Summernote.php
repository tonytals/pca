<?php

namespace ProntuarioEletronico;

use Illuminate\Database\Eloquent\Model;

class Summernote extends Model
{
    //
}
