<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="container-fluid">
    <div class="block-header"></div>

		<div class="row">

      <?php if($errors->all()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
                <?php echo e($value); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>


      <?php if(isset($familia)): ?>
          <painel titulo='ATUALIZAR FAMÍLIA'>
            <formulario id="adicionaFamilia" method="put" action="<?php echo e(route('familias.update', $familia->id)); ?>" token="<?php echo e(csrf_token()); ?>">
      <?php else: ?>
          <painel titulo='ADICIONAR FAMÍLIA'>
            <formulario id="adicionaFamilia" method="post" action="<?php echo e(route('familias.store')); ?>" token="<?php echo e(csrf_token()); ?>">
            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>" />
      <?php endif; ?>
            <input type="hidden" class="form-control" name="unidade_saude" placeholder="" value="<?php echo e(old('unidade_saude', $familia->unidade_saude ?? $unidadesDeSaude->id)); ?>">
      
          <div class="row">
            <div class="col-sm-3">
              <div class="form-group form-float">
                  <div class="form-line">
                      <input type="text" required class="form-control" name="siab" placeholder="" value="<?php echo e(old('siab', $familia->siab ?? null)); ?>">
                      <label class="form-label">Número SIAB</label>
                  </div>
              </div>
            </div>
            <div class="col-sm-3">
              <div class="form-group form-float">
                  <div class="form-line">
                      <input type="text" class="form-control" name="segmento" placeholder="" value="<?php echo e(old('segmento', $familia->segmento ?? null)); ?>">
                      <label class="form-label">Segmento</label>
                  </div>
              </div>
            </div>
            <div class="col-sm-3">
              <div class="form-group form-float">
                  <div class="form-line">
                      <input type="text" class="form-control" name="area" placeholder="" value="<?php echo e(old('area', $familia->area ?? null)); ?>">
                      <label class="form-label">Área</label>
                  </div>
              </div>
            </div>
            <div class="col-sm-3">
              <div class="form-group form-float">
                  <div class="form-line">
                      <input type="text" class="form-control" name="microarea" placeholder="" value="<?php echo e(old('microarea', $familia->microarea ?? null)); ?>">
                      <label class="form-label">Microárea</label>
                  </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-12">
              <div class="form-group form-float">
                  <div class="form-line">
                      <input required type="text" class="form-control" name="sobrenome" placeholder="" value="<?php echo e(old('sobrenome', $familia->sobrenome ?? null)); ?>">
                      <label class="form-label">Sobrenome</label>
                  </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-2">
              <div class="form-group form-float">
                  <div class="form-line">
                      <input type="text" required class="form-control cep" name="cep" placeholder="" value="<?php echo e(old('cep', $familia->cep ?? null)); ?>">
                      <label class="form-label">CEP</label>
                  </div>
              </div>
            </div>
            <div class="col-sm-1">
              <div class="form-group form-float">
                  <div class="form-line">
                      <input type="text" required id="estado" class="form-control" name="estado" placeholder="" value="<?php echo e(old('estado', $familia->estado ?? null)); ?>">
                      <label class="form-label">Estado</label>
                  </div>
              </div>
            </div>
            <div class="col-sm-4">
              <div class="form-group form-float">
                  <div class="form-line">
                      <input type="text" required id="cidade" class="form-control" name="cidade" placeholder="" value="<?php echo e(old('cidade', $familia->cidade ?? null)); ?>">
                      <label class="form-label">Cidade</label>
                  </div>
              </div>
            </div>
            <div class="col-sm-4">
              <div class="form-group form-float">
                  <div class="form-line">
                      <input type="text" required id="endereco" class="form-control" name="endereco" placeholder="" value="<?php echo e(old('endereco', $familia->endereco ?? null)); ?>">
                      <label class="form-label">Endereço</label>
                  </div>
              </div>
            </div>
            <div class="col-sm-1">
              <div class="form-group form-float">
                  <div class="form-line">
                      <input type="text" required id="numero" class="form-control" name="numero" placeholder="" value="<?php echo e(old('numero', $familia->numero ?? null)); ?>">
                      <label class="form-label">Número</label>
                  </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-3">
              <div class="form-group form-float">
                  <div class="form-line">
                      <input id="bairro" type="text" class="form-control" name="bairro" placeholder="" value="<?php echo e(old('bairro', $familia->bairro ?? null)); ?>">
                      <label class="form-label">Bairro</label>
                  </div>
              </div>
            </div>
            <div class="col-sm-9">
              <div class="form-group form-float">
                  <div class="form-line">
                      <input id="complemento" type="text" class="form-control" name="complemento" placeholder="" value="<?php echo e(old('complemento', $familia->complemento ?? null)); ?>">
                      <label class="form-label">Complemento</label>
                  </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-4">
              <div class="form-group form-float">
                  <div class="form-line">
                      <input id="telefone" type="text" class="form-control telefone" name="telefone" placeholder="" value="<?php echo e(old('telefone', $familia->telefone ?? null)); ?>">
                      <label class="form-label">Telefone</label>
                  </div>
              </div>
            </div>
            <div class="col-sm-4">
              <div class="form-group form-float">
                  <div class="form-line">
                      <input id="celular" type="text" class="form-control celular" name="celular" placeholder="" value="<?php echo e(old('celular', $familia->celular ?? null)); ?>">
                      <label class="form-label">Celular</label>
                  </div>
              </div>
            </div>
            <div class="col-sm-4">
              <div class="form-group form-float">
                  <div class="form-line">
                      <input id="renda_familiar" type="text" class="form-control dinheiro" name="renda_familiar" placeholder="" value="<?php echo e(old('renda_familiar', $familia->renda_familiar ?? null)); ?>">
                      <label class="form-label">Renda Familiar</label>
                  </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-4">
              <div class="form-group form-float">
                <div class="form-line">
                  <div class="form-line">
                      <input list="tipos-de-casa" id="tipo_casa" type="text" class="form-control" name="tipo_casa" placeholder="" value="<?php echo e(old('tipo_casa', $familia->tipo_casa ?? null)); ?>">
                      <label class="form-label">Tipo de Casa</label>
                  </div>
                  <datalist id="tipos-de-casa">
                    <option>Tijolo/Adobe</option>
                    <option>Taipa Revestida</option>
                    <option>Taipa Não Revestida</option>
                    <option>Madeira</option>
                    <option>Material Aproveitado</option>
                  </datalist>
                </div>
              </div>
              <div class="row">
                <div class="col-sm-6 text-center">
                  <div class="switch-title">No. de Cômodos / Peças</div>
                  <div class="input-group spinner" data-trigger="spinner">
                      <div class="form-line">
                          <input type="text" id="numero_comodos" name="numero_comodos" class="form-control text-center" value="1" data-rule="quantity">
                      </div>
                      <span class="input-group-addon">
                          <a href="javascript:;" class="spin-up" data-spin="up"><i class="glyphicon glyphicon-chevron-up"></i></a>
                          <a href="javascript:;" class="spin-down" data-spin="down"><i class="glyphicon glyphicon-chevron-down"></i></a>
                      </span>
                  </div>
                </div>
                <div class="col-sm-6 text-center">
                  <div class="switch-title">Energia Elétrica</div>
                  <div class="switch" style="bottom: -10px;position: relative;">
                      <label>Não<input type="checkbox" id="energia_eletrica" name="energia_eletrica" checked><span class="lever switch-col-green"></span>Sim</label>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-sm-4">
              <div class="form-group form-float">
                  <div class="form-line">
                    <select class="form-control show-tick" id="tratamento_agua" name="tratamento_agua" data-live-search="true">
                        <option disabled selected value>-- Tratamento de Água --</option>
                        <option value="Filtração">Filtração</option>
                        <option value="Fervura">Fervura</option>
                        <option value="Cloração">Cloração</option>
                        <option value="Sem tratamento">Sem tratamento</option>
                    </select>
                  </div>
              </div>

              <div class="row">
                <div class="col-sm-12">
                  <div class="form-group form-float">
                    <div class="form-line">
                      <div class="form-line">
                          <input list="abastecimento_agua_list" id="abastecimento_agua" type="text" class="form-control" name="abastecimento_agua" placeholder="" value="<?php echo e(old('abastecimento_agua', $familia->abastecimento_agua ?? null)); ?>">
                          <label class="form-label">Abastecimento de Água</label>
                      </div>
                      <datalist id="abastecimento_agua_list">
                        <option>Rede pública</option>
                        <option>Poço</option>
                        <option>Nascente</option>
                      </datalist>
                    </div>
                  </div>
                </div>
              </div>

            </div>

            <div class="col-sm-4">
              <div class="form-group form-float">
                  <div class="form-line">
                    <select class="form-control show-tick" id="destino_lixo" name="destino_lixo" data-live-search="true">
                        <option disabled selected value>-- Destino do Lixo --</option>
                        <option value="Coletado">Coletado</option>
                        <option value="Queimado">Queimado</option>
                        <option value="Enterrado">Enterrado</option>
                        <option value="Céu aberto">Céu aberto</option>
                    </select>
                  </div>
              </div>

              <div class="row">
                <div class="col-sm-12">
                  <div class="form-group form-float">
                      <div class="form-line">
                        <select class="form-control show-tick" id="destino_fezes_urina" name="destino_fezes_urina" data-live-search="true">
                            <option disabled selected value>-- Destino de Fezes e Urina --</option>
                            <option value="Sistema de esgoto (Rede Geral)">Sistema de esgoto (Rede Geral)</option>
                            <option value="Fossa">Fossa</option>
                            <option value="Céu aberto">Céu aberto</option>
                        </select>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-4">
              <h5>A família é beneficiária do Programa Bolsa Família?</h5>
              <div class="switch">
                  <label>Não<input type="checkbox" id="bolsa_familia" name="bolsa_familia"><span class="lever switch-col-green"></span>Sim</label>
              </div>
            </div>
            <div class="col-sm-4">
              <div class="form-group form-float" id="nisDoResponsavel">
                  <div class="form-line">
                      <input id="nis_responsavel" type="text" class="form-control" name="nis_responsavel" placeholder="" value="<?php echo e(old('nis_responsavel', $familia->nis_responsavel ?? null)); ?>">
                      <label class="form-label">Nis do Responsável</label>
                  </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-12">
              <h5>A família está inscrita no Cadastramento Único de Programas Sociais do Governo Federal (CAD-Único)?</h5>
              <div class="switch">
                  <label>Não<input type="checkbox" id="cad_unico" name="cad_unico"><span class="lever switch-col-green"></span>Sim</label>
              </div>
            </div>
          </div>

        <div class="align-right">
            <button class="btn btn-link waves-effect">SALVAR</button>
        </div>

      </formulario>
    </painel>
  </div>

</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('includeJs'); ?>
  <?php echo $__env->make('layouts.includes.select', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.formValidator', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.inputMask', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.spinner', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
$(function () {
    $('#adicionaFamilia').validate({
      rules : {

      },
      messages:{

      },
      highlight: function (input) {
          $(input).parents('.form-line').addClass('error');
      },
      unhighlight: function (input) {
          $(input).parents('.form-line').removeClass('error');
      },
      errorPlacement: function (error, element) {
          $(element).parents('.form-group').append(error);
      }
    });
    $('#adicionaFamilia').find('input[required]').css('border-bottom','solid thin red');
    $('.required').css('border-bottom','solid thin red');

    <?php if(isset($familia)): ?>
        $('#adicionaFamilia').find('input').focus();
    <?php endif; ?>

});
$('#estado_civil_id').on('keydown', function (e, clickedIndex, isSelected, previousValue) {
  console.log(e);
});
$(".cep").focusout(function(){
		$.ajax({
			url: 'https://viacep.com.br/ws/'+$(this).val()+'/json/unicode/',
			dataType: 'json',
			success: function(resposta){
				$("#endereco").val(resposta.logradouro).focus();
				$("#complemento").val(resposta.complemento).focus();
				$("#bairro").val(resposta.bairro).focus();
				$("#cidade").val(resposta.localidade).focus();
				$("#estado").val(resposta.uf).focus();
				$("#numero").parents('.form-line').addClass('error');
        $("#numero").addClass('error').focus();
			}
		});
});
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>