<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="container-fluid">
		<div class="block-header"></div>

		<div class="row">
      <painel titulo='Lista de Papéis para <?php echo e($usuario->name); ?>'>
				<div class="row">
					<form action="<?php echo e(route('usuarios.papel.store',$usuario->id)); ?>" method="post">
					<?php echo e(csrf_field()); ?>

					<div class="input-field">
						<select name="papel_id">
							<?php $__currentLoopData = $papel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($valor->id); ?>"><?php echo e($valor->nome); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
						<button class="btn blue">Adicionar</button>
					</form>
					</div>
					<div class="row">

						<div class="table-responsive">
							<table class="table table-bordered table-striped table-hover js-basic-example dataTable">
								<thead>
								<tr>
									<th>Papel</th>
									<th>Descrição</th>
									<th>Ação</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $usuario->papeis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $papel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($papel->nome); ?></td>
										<td><?php echo e($papel->descricao); ?></td>

										<td>

											<form action="<?php echo e(route('usuarios.papel.destroy',[$usuario->id,$papel->id])); ?>" method="post">
													<?php echo e(method_field('DELETE')); ?>

													<?php echo e(csrf_field()); ?>

													<button title="Deletar" class="btn btn-danger waves-effect"><i class="material-icons">delete</i></button>
											</form>
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
					</div>
			</painel>
		</div>
	</div>

</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('includeJs'); ?>
  <?php echo $__env->make('layouts.includes.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.select', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>