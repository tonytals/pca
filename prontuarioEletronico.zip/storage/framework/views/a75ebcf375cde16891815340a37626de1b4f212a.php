<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="container-fluid">
    <div class="block-header">

    </div>
    <div class="row">
      <painel titulo="<?php echo e($paciente); ?>">
        <small slot="small">Prontuários</small>
        <a href="<?php echo e(route('pacientes.adicionar')); ?>" class="btn btn-primary waves-effect">Adicionar Registro</a>

        <tabela-de-listagem
        v-bind:colunas="<?php echo e($tituloColunas); ?>"
        v-bind:registros="<?php echo e($prontuarios); ?>"
        acoes='prontuarios'

      ></tabela-de-listagem>
    </painel>
		</div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('includeJs'); ?>
  <?php echo $__env->make('layouts.includes.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>