<script src="<?php echo e(asset('plugins/jquery-countto/jquery.countTo.js')); ?>"></script>
