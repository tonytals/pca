<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="container-fluid">
    <div class="block-header">
      <h2></h2>
    </div>
  </div>

  <div class="row">
    <div class="col-sm-12">
      <painel titulo='CALENDÁRIO'>
        <div class="row">
            <?php echo $calendar->calendar(); ?>

        </div>
      </painel>
    </div>
  </div>

</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('includeJs'); ?>
  <?php echo $__env->make('layouts.includes.calendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.dialogs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('beforeCloseBody'); ?>
  <?php echo $calendar->script(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>