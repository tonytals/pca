<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="container-fluid">
    <div class="block-header">
      <h2>PORTFÓLIO CLÍNICO</h2>
    </div>


    <div class="row clearfix">

        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="card">
              <div class="header">

                  <h2><?php echo e($paciente->nome_completo); ?></h2>

              </div>
                <div class="body">
                  <div class="row clearfix">
                    <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                      <img src="https://cdn2.iconfinder.com/data/icons/lil-faces/226/lil-face-14-512.png" style="max-width:100%" alt="..." class="img-thumbnail">
                    </div>
                    <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
                      <ul class="list-unstyled">
                        <li><b>Data de Nascimento:</b> <?php echo e($paciente->data_nascimento); ?> </li>
                        <li><b>CPF:</b> <span class="cpf"><?php echo e($paciente->cpf); ?></span></li>
                        <li><b>RG:</b> <?php echo e($paciente->rg); ?></li>
                        <li><b>Estado Civil:</b> <?php echo e($paciente->estado_civil['estado_civil']); ?></li>
                        <li><b>Tipo Sanguineo:</b> <?php echo e($paciente->tipo_sanguineo['tipo_sanguineo']); ?></li>
                        <li><b>E-mail:</b> <?php echo e($paciente->email); ?></li>
                        <li><b>Nome do Pai:</b> <?php echo e($paciente->nome_pai); ?></li>
                        <li><b>Nome da Mãe:</b> <?php echo e($paciente->nome_mae); ?></li>
                        <li><b>Sexo:</b> <?php echo e($paciente->sexo); ?></li>
                        <li><b>Religião:</b> <?php echo e($paciente->religiao); ?></li>
                      </ul>
                    </div>
                    <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
                      <ul class="list-unstyled">
                        <li>
                          <button type="button" class="btn btn-primary btn-block btn-lg waves-effect">
                              <i class="material-icons">print</i>
                              <span>Imprimir</span>
                          </button>
                        </li>
                        <li>
                          <br />
                          <button type="button" class="btn btn-success btn-block btn-lg waves-effect">
                              <i class="material-icons">file_download</i>
                              <span>Baixar Prontuário</span>
                          </button>
                        </li>
                        <li>
                          <br />
                          <button type="button" class="btn bg-teal btn-block btn-lg waves-effect" data-toggle="modal" data-target="#adicionarRegistro">
                              <i class="material-icons">add</i>
                              <span>Adicionar Um Novo Registro</span>
                          </button>
                        </li>
                      </ul>
                    </div>
                  </div>
                <div class="row clearfix">
                  <?php $__env->startComponent('comments::components.comments', ['model' => $prontuarios]); ?>
                  <?php echo $__env->renderComponent(); ?>
                </div>
            </div>
        </div>
      </div>
    </div>


  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('includeJs'); ?>
  <?php echo $__env->make('layouts.includes.inputMask', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.select', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.modals', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  $("span.cpf").inputmask("999.999.999-99");
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>