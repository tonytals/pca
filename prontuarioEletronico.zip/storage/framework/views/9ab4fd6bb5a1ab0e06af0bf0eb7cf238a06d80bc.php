
<ul class="list-unstyled" >
<?php if(isset($reply) && $reply === true): ?>
  <ul style="list-style: none;margin: -18px 0 0 0;" id="comment-<?php echo e($comment->id); ?>">
    <div class="header bg-green">
      <h2>
          <?php echo e(Date::parse($comment->created_at)->format('j \d\e F\, Y')); ?> <small><?php echo e($comment->commenter->name); ?></small>
      </h2>
    </div>
<?php else: ?>
  <li id="comment-<?php echo e($comment->id); ?>">
<?php endif; ?>
    <div class="card">
      <?php if(!isset($reply)): ?>
        <div class="header">
          <h2>
              <?php echo e(Date::parse($comment->data_hora_atendimento)->format('j \d\e F\, Y')); ?> <small><?php echo e($comment->commenter->name); ?></small>
          </h2>
          <ul class="header-dropdown m-r-0">
            <li>
                <i class="material-icons">place</i><?php echo e($comment->local_atendimento); ?>

            </li>
            <li>
                <i class="material-icons">watch</i> ------
            </li>
          </ul>
        </div>
      <?php endif; ?>
    <div class="body" id="registrosPaciente">
        <h5 ><?php echo e($comment->commenter->name); ?> <small>- <?php echo e($comment->created_at->diffForHumans()); ?></small></h5>

        <p><?php echo $comment->comment; ?></p>

        <div style="float:right">
          <?php if(Auth::user()->id != $comment->commenter->id): ?>
            <modal-link titulo="Responder" css="nenhum" modal="reply-modal-<?php echo e($comment->id); ?>"></modal-link> |
          <?php endif; ?>

          <modal-link style="display:none;" titulo="Editar" css="nenhum" modal="comment-modal-<?php echo e($comment->id); ?>"></modal-link> 
          <a style="display:none;" href="<?php echo e(url('comments/' . $comment->id)); ?>" onclick="event.preventDefault();document.getElementById('comment-delete-form-<?php echo e($comment->id); ?>').submit();" >Deletar</a>
          <form id="comment-delete-form-<?php echo e($comment->id); ?>" action="<?php echo e(url('comments/' . $comment->id)); ?>" method="POST" style="display: none;">
              <?php echo method_field('DELETE'); ?>
              <?php echo csrf_field(); ?>
          </form>
        </div>
      </div>

      <modal titulo="Responder Análise" modal="reply-modal-<?php echo e($comment->id); ?>">
        <form method="POST" action="<?php echo e(url('comments/' . $comment->id)); ?>">
            <?php echo csrf_field(); ?>
            <div>
              <div class="form-group">
                  <div class="form-line">
                      <textarea rows="4" class="form-control no-resize summernote" name="message" placeholder="Por favor digite o comentário..."></textarea>
                  </div>
              </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CANCELAR</button>
                <button type="submit" class="btn btn-link waves-effect">RESPONDER</button>
            </div>
        </form>
      </modal>

      <modal titulo="Editar Análise" modal="comment-modal-<?php echo e($comment->id); ?>">
        <form method="POST" action="<?php echo e(url('comments/' . $comment->id)); ?>">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div>
              <div class="form-group">
                  <div class="form-line">
                    <label for="message">Atualize sua mensagem:</label>
                      <textarea rows="4" class="form-control no-resize summernote" name="message"><?php echo e($comment->comment); ?></textarea>
                  </div>
              </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CANCELAR</button>
                <button type="submit" class="btn btn-link waves-effect">SALVAR</button>
            </div>
        </form>
      </modal>

    </div>
        <br />

        <?php $__currentLoopData = $comment->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('comments::_comment', [
                'comment' => $child,
                'reply' => true
            ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(isset($reply) && $reply === true): ?>
</ul>
<?php else: ?>
  </li>
<?php endif; ?>
