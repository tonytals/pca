<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="container-fluid">
    <div class="block-header">
      <h2>DASHBOARD</h2>
    </div>

      <div class="row clearfix">
          <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
              <div class="info-box bg-teal hover-expand-effect">
                  <div class="icon">
                      <a href="<?php echo e(route('pacientes.index')); ?>">
                        <i class="material-icons">person</i>
                      </a>

                  </div>
                  <div class="content">
                      <div class="text">PACIENTES</div>
                      <div class="number count-to" data-from="0" data-to="<?php echo e($quantidade_pacientes); ?>" data-speed="1000" data-fresh-interval="20"></div>
                  </div>
              </div>

          </div>
          <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
              <div class="info-box bg-green hover-expand-effect">
                  <div class="icon">
                      <a href="#">
                        <i class="material-icons">forum</i>
                      </a>

                  </div>
                  <div class="content">
                      <div class="text">REGISTROS</div>
                      <div class="number count-to" data-from="0" data-to="<?php echo e($quantidade_comentarios); ?>" data-speed="1000" data-fresh-interval="20"></div>
                  </div>
              </div>

          </div>
      </div>

      <div class="row clearfix">
          <!-- Task Info -->
          <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
            <painel titulo='PRÓXIMAS VISITAS/ATENDIMENTOS'>
              <div class="table-responsive">
                  <table class="table table-hover dashboard-task-infos">
                      <thead>
                          <tr>
                              <th>Nome</th>
                              <th>Data do Agendamento</th>
                              <th>Notificação</th>
                          </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td> <a href="<?php echo e(route('pacientes.show', $item->getOriginal('paciente_id'))); ?>"><?php echo e($item->paciente_id); ?></a> </td>
                            <td><?php echo e(Date::parse($item->data_inicio)->format('j \d\e F\, Y \- H:m')); ?></td>
                            <td><span class="label bg-green"><?php echo e(strip_tags($item->notificacao['comment'])); ?></span></td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div>
            </painel>
          </div>
          <!-- #END# Task Info -->
          <!-- Browser Usage -->
          <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <div class="card">
                <div class="body bg-teal">
                    <div class="font-bold m-b--35">N. de Atendimentos</div>
                      <ul class="dashboard-stat-list">
                        <?php $__currentLoopData = $locais_atendimento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($local[0]->local_atendimento != null): ?>
                            <li><?php echo e($local[0]->local_atendimento); ?>

                              <span class="pull-right"><b><?php echo e($local->count()); ?></b> <small></small></span>
                            </li>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
          </div>
          <!-- #END# Browser Usage -->
      </div>

  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('includeJs'); ?>
  <?php echo $__env->make('layouts.includes.countTo', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
$(function () {
    $('.count-to').countTo();
  });
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>