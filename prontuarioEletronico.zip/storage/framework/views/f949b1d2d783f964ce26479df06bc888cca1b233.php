<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="container-fluid">
    <div class="block-header">
      <h2>PORTFÓLIO CLÍNICO</h2>
    </div>


    <div class="row clearfix">

        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="card">
              <div class="header">

                  <h2><?php echo e($paciente->nome_completo); ?></h2><small><a href="<?php echo e(route('familias.show', $paciente->getOriginal('familia_id'))); ?>"><?php echo e($paciente->familia_id); ?></a></small>

                </div>
                <div class="body" id="prontuarioPaciente">
                  <div class="row clearfix">
                    <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2" id="fotoPaciente">
                      <div class="image-area">
                          <img src="<?php echo e($paciente->foto); ?>" style="max-width:100%" alt="<?php echo e($paciente->nome_completo); ?>" class="img-thumbnail">
                      </div>
                    </div>
                    <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5" id="dadosPaciente">
                      <span class="font-bold align-center col-cyan"><?php echo e($paciente->alfabetizado); ?></span>
                      <span class="font-bold align-center col-cyan"><?php echo e($paciente->frequenta_escola); ?></span>
                      <span class="font-bold align-center col-cyan"><?php echo e($paciente->chefe_familia); ?></span>
                      <ul class="list-unstyled">
                        <li><b>Data de Nascimento:</b> <?php echo e(Date::parse($paciente->data_nascimento)->format('j \d\e F\, Y') . ' ('. Date::parse($paciente->data_nascimento)->age .' anos)'); ?> </li>
                        <li><b>CPF:</b> <span><?php echo e(mascara("###.###.###-##", $paciente->cpf)); ?></span></li>
                        <li><b>RG:</b> <?php echo e($paciente->rg); ?></li>
                        <li><b>Estado Civil:</b> <?php echo e($paciente->estado_civil['estado_civil']); ?></li>
                        <li><b>Tipo Sanguineo:</b> <?php echo e($paciente->tipo_sanguineo_id); ?></li>
                        <li><b>E-mail:</b> <?php echo e($paciente->email); ?></li>
                        <li><b>Nome do Pai:</b> <?php echo e($paciente->nome_pai); ?></li>
                        <li><b>Nome da Mãe:</b> <?php echo e($paciente->nome_mae); ?></li>
                        <li><b>Sexo:</b> <?php echo e($paciente->sexo); ?></li>
                        <li><b>Religião:</b> <?php echo e($paciente->religiao); ?></li>
                        <li><b>Ocupação:</b> <?php echo e($paciente->ocupacao); ?></li>
                        <li><b>Condições Referidas:</b><br/>
                          <?php $__currentLoopData = $paciente->condicoes_referidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="label bg-grey"><?php echo e($valor->sigla . ' - ' . $valor->nome); ?></span>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </li>
                      </ul>
                    </div>
                    <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
                      <ul class="list-unstyled" id="botoes">
                        <li>
                          <br />
                          <button type="button" id="baixarProntuario" class="btn btn-success btn-block btn-lg waves-effect">
                              <i class="material-icons">file_download</i>
                              <span>Baixar Prontuário</span>
                          </button>
                        </li>
                        <li>
                          <br />
                          <button type="button" class="btn bg-teal btn-block btn-lg waves-effect" data-toggle="modal" data-target="#adicionarRegistro">
                              <i class="material-icons">add</i>
                              <span>Adicionar Um Novo Registro</span>
                          </button>
                        </li>
                        <li>
                          <br />
                          <button type="button" class="btn bg-green btn-block btn-lg waves-effect" data-toggle="modal" data-target="#adicionarAgenda">
                              <i class="material-icons">date_range</i>
                              <span>Agendar Visita</span>
                          </button>
                        </li>
                      </ul>
                    </div>
                  </div>
                <div class="row clearfix">
                  <?php $__env->startComponent('comments::components.comments', ['model' => $paciente]); ?>
                  <?php echo $__env->renderComponent(); ?>
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="adicionarAgenda" tabindex="-1" role="dialog">
      <div class="modal-dialog modal-lg" role="document">
          <div class="modal-content">
              <div class="modal-header">
                  <h4 class="modal-title" id="adicionarAgendaLabel">Agendar Visita: <?php echo e($paciente->nome_completo); ?></h4>
              </div>
              <form method="POST" action="<?php echo e(route('agendamentos.store')); ?>">
                <div class="modal-body">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="paciente_id" value="<?php echo e($paciente->id); ?>">
                  <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                  <div class="row clearfix">
                    <div class="col-sm-6">
                      <div class="form-group">
                          <div class="form-line">
                              <input type="text" class="datetimepicker form-control" name="data_inicio" id="data_inicio" placeholder="Selecione Data e Hora para a visita...">
                          </div>
                      </div>
                    </div>
                  </div>
                  <div class="row clearfix">
                    <div class="col-sm-12">
                      <div class="form-group">
                          <div class="form-line">
                              <textarea rows="3" id="observacao" class="form-control no-resize" name="observacao" placeholder="Digite sua observação..."></textarea>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-link waves-effect">SALVAR</button>
                    <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">FECHAR</button>
                </div>
              </form>
          </div>
      </div>
  </div>

</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('includeJs'); ?>
  <?php echo $__env->make('layouts.includes.inputMask', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.select', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.modals', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.summernote', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.datetimepicker', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.dialogs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.pdf', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
$(function () {
    $('.summernote').summernote({
      tabsize: 2,
      lang: 'pt-BR',
      height: 180
    });
    $('.datetimepicker').bootstrapMaterialDatePicker({
        format: 'dddd DD MMMM YYYY HH:mm',
        weekStart: 0,
        lang: 'pt-BR',
        time: true,
    });
  });
  $('#baixarProntuario').click(function () {
    $('#botoes').hide();
    swal({
        title: "Aguarde",
        text: "Estamos criando seu PDF, pode levar alguns segundos =)",
        type: "warning"
      });
    html2canvas(document.querySelector("#prontuarioPaciente")).then(function(canvas) {
        var doc = new jsPDF();
        var specialElementHandlers = {
            '#editor': function (element, renderer) {
                return true;
            }
        };
        doc.addImage(canvas, 'PNG', 10, 10, 190, 114);
        doc.save('thisMotion.pdf');
        $('#botoes').show();
        swal({
            title: "Tudo bem",
            text: "PDF gerado com sucesso",
            type: "success"
          });
    });
  });
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>