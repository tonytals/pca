<link href="<?php echo e(asset('plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css')); ?>" rel="stylesheet" />
<script src="<?php echo e(asset('plugins/momentjs/moment.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/momentjs/moment-with-locales.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js')); ?>"></script>
