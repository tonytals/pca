
<script src="<?php echo e(asset('plugins/jquery-validation/jquery.validate.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery-validation/additional-methods.js')); ?>"></script>
