<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="container-fluid">
    <div class="block-header">

    </div>
    <div class="row">
      <painel titulo='FAMÍLIAS CADASTRADAS'>
        <a href="<?php echo e(route('familias.adicionar')); ?>" class="btn btn-primary waves-effect">Adicionar Nova Família</a>

      <div class="row clearfix">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <div class="table-responsive">
              <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                  <thead>
                      <tr>
                          <th>SIAB</th>
                          <?php if(Auth::user()->eAdmin()): ?>
                            <th>Preceptor</th>
                            <th>Aluno</th>
                          <?php endif; ?>
                          <th>Qtd de Pessoas</th>
                          <th>Ações</th>
                      </tr>
                  </thead>
                  <tfoot>
                      <tr>
                        <th>SIAB</th>
                        <?php if(Auth::user()->eAdmin()): ?>
                          <th>Preceptor</th>
                          <th>Aluno</th>
                        <?php endif; ?>
                        <th>Qtd de Pessoas</th>
                        <th>Ações</th>
                      </tr>
                  </tfoot>
                  <tbody>
                    <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><a href="<?php echo e(route('familias.show', $familia->id)); ?>"><?php echo e($familia->siab); ?></a></td>
                        <?php if(Auth::user()->eAdmin()): ?>
                          <td><?php echo e($familia->unidade_saude); ?></td>
                          <td><?php echo e($familia->user_id); ?></td>
                        <?php endif; ?>
                        <td><?php echo e($familia->contador); ?></td>
                        <td>
                          <form action="<?php echo e(route('familias.destroy', $familia->id)); ?>" method="post">
                            <a title="Editar" class="btn btn-primary waves-effect" href="<?php echo e(route('familias.edit', $familia->id)); ?>">
                              <i class="material-icons">mode_edit</i>
                            </a>
                            <input type="hidden" name="_method" value="DELETE" />
                            <?php echo csrf_field(); ?>

                            <button type="submit" title="Excluir" class="btn btn-danger waves-effect">
                              <i class="material-icons">delete</i>
                            </button>
                          </form>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
          </div>
        </div>
      </div>

    </painel>

  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('includeJs'); ?>
  <?php echo $__env->make('layouts.includes.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>