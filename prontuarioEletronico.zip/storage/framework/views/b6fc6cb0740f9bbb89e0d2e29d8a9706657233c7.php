<link href="<?php echo e(asset('plugins/jquery-spinner/css/bootstrap-spinner.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('plugins/jquery-spinner/js/jquery.spinner.js')); ?>"></script>
