<link href="<?php echo e(asset('plugins/multi-select/css/multi-select.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('plugins/multi-select/js/jquery.multi-select.js')); ?>"></script>
