<link href="<?php echo e(asset('plugins/dropzone/dropzone.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('plugins/dropzone/dropzone.js')); ?>"></script>
