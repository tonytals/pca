<?php $__env->startSection('content'); ?>

<section class="content">
  <div class="container-fluid">
    <div class="block-header"></div>

		<div class="row">
      <painel titulo='PERMISSÕES PARA O PAPEL: <?php echo e($papel->nome); ?>'>

				<div class="row">
					<form action="<?php echo e(route('papeis.permissao.store',$papel->id)); ?>" method="post">
						<?php echo e(csrf_field()); ?>

						<div class="col-sm-4">
							<div class="input-field">
								<select name="permissao_id" class="form-control show-tick" data-live-search="true">
									<?php $__currentLoopData = $permissao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($valor->id); ?>"><?php echo e($valor->nome); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
						<div class="col-sm-4">
							<button class="btn btn-primary waves-effect">Adicionar</button>
						</div>
					</form>


				</div>

				<div class="row">
					<div class="table-responsive">
						<table class="table table-bordered table-striped table-hover js-basic-example dataTable">
							<thead>
							<tr>
								<th>Permissão</th>
								<th>Descrição</th>
								<th>Ação</th>
							</tr>
						</thead>
						<tbody>
						<?php $__currentLoopData = $papel->permissoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($permissao->nome); ?></td>
								<td><?php echo e($permissao->descricao); ?></td>
								<td>
									<form action="<?php echo e(route('papeis.permissao.destroy',[$papel->id,$permissao->id])); ?>" method="post">
											<?php echo e(method_field('DELETE')); ?>

											<?php echo e(csrf_field()); ?>

											<button title="Deletar" class="btn bg-red"><i class="material-icons">delete</i></button>
									</form>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
					</div>
				</div>


    </painel>
		</div>


  </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('includeJs'); ?>
	<?php echo $__env->make('layouts.includes.select', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>