<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title><?php echo e(config('app.name', 'prontuario eletronico')); ?></title>
    <!-- Favicon-->
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <script type="text/javascript">
        window.Laravel = <?php echo json_encode([
                        'csrfToken' => csrf_token(),
                        'userPapeis' => Auth::user()->papeis,
                        'permissoes' => Auth::user()->getMinhasPermissoes->pluck('permissoes')
                    ]); ?>
    </script>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="<?php echo e(asset('plugins/node-waves/waves.css')); ?>" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="<?php echo e(asset('plugins/animate-css/animate.css')); ?>" rel="stylesheet" />

    <link href="<?php echo e(asset('css/themes/all-themes.css')); ?>" rel="stylesheet" />
    <!-- Custom Css -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
</head>

<body class="theme-teal">
  <!-- preloader de página -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-teal">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Um instante...</p>
        </div>
    </div>
  <!-- ##fim do preloader de página -->
  <!-- Overlay -->
  <div class="overlay"></div>
  <!-- #fim Overlay -->

  <div id="app">
    <?php echo $__env->make('layouts.partials.barraPesquisa', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts.partials.barraTopo', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section>
      <aside id="leftsidebar" class="sidebar">
        <?php echo $__env->make('layouts.partials.informacoesUsuario', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <menu-principal></menu-principal>
        <div class="legal">
          <div class="copyright">
            © 2018 <a href="javascript:void(0);"><?php echo e(config('app.name', 'prontuario eletronico')); ?></a>.
          </div>
          <div class="version"><b>Versão: </b> <?php echo app('pragmarx.version')->format('compact'); ?></div><br />
        </div>
      </aside>
    </section>
    <?php echo $__env->yieldContent('content'); ?>

  </div>

  <!--
  ## JQUERY COMPILADO
  -->
  <script src="<?php echo e(asset('js/app.js')); ?>"></script>

  <script src="<?php echo e(asset('plugins/bootstrap-notify/bootstrap-notify.js')); ?>"></script>
  <script src="<?php echo e(asset('plugins/notifications.js')); ?>"></script>
  <script src="<?php echo e(asset('plugins/node-waves/waves.js')); ?>"></script>
  <script src="<?php echo e(asset('plugins/jquery-validation/jquery.validate.js')); ?>"></script>

  <script src="<?php echo e(asset('js/admin.js')); ?>"></script>
  <?php if(session()->has('info')): ?>
    <script type="text/javascript">
        $(function () {
          $.notify({
              message: 'Sem permissão para acessar esse paciente!'
          }, {
            allow_dismiss: true,
            newest_on_top: true,
            timer: 1000,
            placement: {
                from: 'bottom',
                align: 'right'
            },
          	animate: {
          		enter: 'animated fadeInDown',
          		exit: 'animated fadeOutUp'
          	},
            template:
              '<div class="alert bg-red alert-dismissible col-sm-4" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><strong>Sem permissão para acessar!</strong></div>'
          });
        });
    </script>
  <?php endif; ?>
  <?php if(session()->has('sucesso')): ?>
    <script type="text/javascript">
        $(function () {
          $.notify({
              message: 'Criado Com Sucesso!'
          }, {
            allow_dismiss: true,
            newest_on_top: true,
            timer: 1000,
            placement: {
                from: 'bottom',
                align: 'right'
            },
          	animate: {
          		enter: 'animated fadeInDown',
          		exit: 'animated fadeOutUp'
          	},
            template:
              '<div class="alert bg-green alert-dismissible col-sm-4" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><strong>Criado Com Sucesso!</strong></div>'
          });
        });
    </script>
  <?php endif; ?>

  <?php echo $__env->yieldContent('includeJs'); ?>

  <script type="text/javascript">
      <?php echo $__env->yieldContent('scripts'); ?>
  </script>

  <?php echo $__env->yieldContent('beforeCloseBody'); ?>

</body>
</html>
