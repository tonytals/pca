<script src="<?php echo e(asset('plugins/pdf/jspdf.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/html2canvas.min.js')); ?>"></script>
