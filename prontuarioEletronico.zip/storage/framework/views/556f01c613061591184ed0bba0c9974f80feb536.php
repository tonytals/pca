<script src="<?php echo e(asset('plugins/modals.js')); ?>"></script>
