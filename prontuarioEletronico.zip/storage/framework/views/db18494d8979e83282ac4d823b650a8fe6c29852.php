<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="container-fluid">
    <div class="block-header"></div>

		<div class="row">
      <painel titulo='EDITAR PAPEL'>
		<form action="<?php echo e(route('papeis.update',$registro->id)); ?>" method="post">

		<?php echo e(csrf_field()); ?>

		<?php echo e(method_field('PUT')); ?>

		<?php echo $__env->make('admin.papel._form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<button class="btn blue">Atualizar</button>


		</form>

  </painel>
  </div>
</div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>