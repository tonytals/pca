<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="container-fluid">
    <div class="block-header"></div>

		<div class="row">
      <painel titulo='USUÁRIOS'>
        <a href="<?php echo e(route('usuarios.adicionar')); ?>" class="btn btn-primary waves-effect">Adicionar Usuário</a>
        <a href="<?php echo e(route('usuarios.importar')); ?>" class="btn bg-teal waves-effect">Importar Usuários (CSV)</a>

        <tabela-de-listagem
        v-bind:colunas="<?php echo e($tituloColunas); ?>"
        v-bind:registros="<?php echo e($usuarios); ?>"
        acoes='usuarios'
        acoesextras='<?php echo e($extras); ?>'
      ></tabela-de-listagem>

      </painel>
		</div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('includeJs'); ?>
  <?php echo $__env->make('layouts.includes.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>