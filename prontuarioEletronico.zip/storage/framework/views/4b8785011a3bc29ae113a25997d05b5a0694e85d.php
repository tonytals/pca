<!-- advancedForms  -->
<link href="<?php echo e(asset('plugins/bootstrap-select/css/bootstrap-select.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('plugins/bootstrap-tagsinput/bootstrap-tagsinput.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('plugins/nouislider/nouislider.min.css')); ?>" rel="stylesheet" />

<script src="<?php echo e(asset('plugins/nouislider/nouislider.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-select/js/bootstrap-select.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery-inputmask/jquery.inputmask.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/multi-select/js/jquery.multi-select.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-tagsinput/bootstrap-tagsinput.js')); ?>"></script>
<!--<script src="<?php echo e(asset('plugins/advanced-form-elements.js')); ?>"></script>
 advancedForms -->
