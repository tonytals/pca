<link href="<?php echo e(asset('plugins/sweetalert/sweetalert.css')); ?>" rel="stylesheet" />
<script src="<?php echo e(asset('plugins/sweetalert/sweetalert.min.js')); ?>"></script>
