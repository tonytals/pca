<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="container-fluid">
    <div class="block-header">
      <h2>ADMIN</h2>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>