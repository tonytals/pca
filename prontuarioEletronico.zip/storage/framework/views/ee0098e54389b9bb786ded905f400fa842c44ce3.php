<?php $__env->startSection('content'); ?>

<section class="content">
  <div class="container-fluid">
    <div class="block-header"></div>

		<div class="row">
      <painel titulo='PAPÉIS DE SISTEMA'>
        <a href="<?php echo e(route('papeis.create')); ?>" class="btn btn-primary waves-effect">Adicionar Novo Papel</a>

        <tabela-de-listagem
        v-bind:colunas="<?php echo e($tituloColunas); ?>"
        v-bind:registros="<?php echo e($registros); ?>"
        acoes='papeis'
        acoesextras='<?php echo e($extras); ?>'

      ></tabela-de-listagem>
    </painel>
		</div>


  </div>
</section>
	<!--<div class="container">
		<h2 class="center">Lista de Papéis</h2>

		<div class="row">
			<table>
				<thead>
					<tr>
						<th>Id</th>
						<th>Nome</th>
						<th>Descrição</th>
						<th>Ação</th>
					</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($registro->id); ?></td>
						<td><?php echo e($registro->nome); ?></td>
						<td><?php echo e($registro->descricao); ?></td>

						<td>


							<form action="<?php echo e(route('papeis.destroy',$registro->id)); ?>" method="post">
								<a title="Editar" class="btn orange" href="<?php echo e(route('papeis.edit',$registro->id)); ?>"><i class="material-icons">mode_edit</i></a>
								<a title="Permissões" class="btn blue" href="<?php echo e(route('papeis.permissao',$registro->id)); ?>"><i class="material-icons">lock_outline</i></a>


									<?php echo e(method_field('DELETE')); ?>

									<?php echo e(csrf_field()); ?>

									<button title="Deletar" class="btn red"><i class="material-icons">delete</i></button>
							</form>








						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

		</div>
		<div class="row">
			<a class="btn blue" href="<?php echo e(route('papeis.create')); ?>">Adicionar</a>
		</div>
	</div>-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>