<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="container-fluid">
    <div class="block-header">
    </div>

    <painel  titulo='GERENCIAR UNIDADE DE SAUDE: <?php echo e($grupo->name); ?>'>

      <formulario method="post" action="<?php echo e(route('grupos.addAluno')); ?>" token="<?php echo e(csrf_token()); ?>" enctype="multipart/form-data">
        <div class="row">
          <div class="col-sm-4">
            <input type="hidden" name="idResponsavel" value="<?php echo e($grupo->users->first()['id']); ?>">
            Responsável: <a href="<?php echo e(route('usuarios.show',$grupo->users->first()['id'])); ?>"><b><?php echo e($grupo->users->first()['name']); ?></b></a>
          </div>
        </div>


        <div class="row">
          <div class="col-sm-12">
            <h5>Adicionar Alunos a Unidade</h5>
          </div>
        </div>
        <div class="row clearfix">
          <div class="col-sm-6">
            <select name="alunosUnidade" id="alunosUnidade" class="form-control show-tick" data-live-search="true">
              <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($aluno->id); ?>"><?php echo e($aluno->name); ?></option>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          <div class="col-sm-4">
            <button type="submit" class="btn bg-teal waves-effect">
                <i class="material-icons">add</i>
                <span>Adicionar</span>
            </button>
          </div>
        </div>
      </formulario>

      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <div class="table-responsive">
              <table class="table table-bordered table-striped table-hover dataTable tabelaPreceptores">
                  <thead>
                      <tr>
                          <th>Nome</th>
                          <th>Ações</th>
                      </tr>
                  </thead>
                  <tfoot>
                      <tr>
                        <th>Nome</th>
                        <th>Ações</th>
                      </tr>
                  </tfoot>
                  <tbody>
                    <?php if($grupo->users->count() > 1): ?>
                      <?php $__currentLoopData = $grupo->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($aluno->id != $grupo->users->first()['id']): ?>
                          <tr>
                            <td><a href="<?php echo e(route('tutor.showAlunosPreceptores', $aluno->id)); ?>"><?php echo e($aluno->name); ?></a></td>
                            <td>
                              <a class="btn btn-danger waves-effect" href="<?php echo e(route('grupos.removeAluno', [$grupo->users->first()['id'], $aluno->id])); ?>">
                                  <i class="material-icons">delete</i>
                                  <span>Remover do Grupo</span>
                              </a>
                            </td>
                          </tr>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                      <tr>
                        <td colspan="2">
                          Sem Registros
                        </td>
                      </tr>
                    <?php endif; ?>
                  </tbody>
              </table>
          </div>
        </div>
      </div>

    </painel>

  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('includeJs'); ?>
  <?php echo $__env->make('layouts.includes.select', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
$(function () {
    $('#alunosUnidade').multiSelect({ selectableOptgroup: true });
});
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>