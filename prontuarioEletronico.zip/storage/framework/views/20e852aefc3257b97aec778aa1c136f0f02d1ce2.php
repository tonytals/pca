<?php $__env->startSection('content'); ?>

<section class="content">
	<div class="container-fluid">
		<div class="block-header"></div>

		<div class="row">
			<painel titulo='ADICIONAR PAPEL'>


				<div class="row">
					<form action="<?php echo e(route('papeis.store')); ?>" method="post">

						<?php echo e(csrf_field()); ?>

						<?php echo $__env->make('admin.papel._form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

						<button class="btn btn-primary waves-effect">Adicionar</button>


					</form>
				</painel>
			</div>

		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>