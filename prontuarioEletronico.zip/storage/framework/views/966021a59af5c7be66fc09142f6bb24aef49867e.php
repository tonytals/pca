<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="container-fluid">
    <div class="block-header">
    </div>

    <div class="row clearfix">

        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="card">
              <div class="header">

                  <h2><?php echo e($familia->siab . ' - ' . $familia->sobrenome); ?></h2><small>Quantidade de Membros: <?php echo e($familia->membros->count()); ?> </small>

              </div>
                <div class="body" id="prontuarioFamilia">
                  <div class="row clearfix">
                    <div class="col-sm-4">
                      <span class="font-bold col-blue-grey">Tipo de Casa:</span> <?php echo e($familia->tipo_casa); ?><br />
                      <span class="font-bold col-blue-grey">Quantidade de Cômodos:</span> <?php echo e($familia->numero_comodos); ?><br />
                      <span class="font-bold col-blue-grey">Energia Elétrica:</span> <?php echo e($familia->energia_eletrica); ?>

                    </div>
                    <div class="col-sm-4">
                      <span class="font-bold col-blue-grey">Tratamento da Água no Domicílio:</span> <?php echo e($familia->tratamento_agua); ?><br />
                      <span class="font-bold col-blue-grey">Abasteciemtno de Água:</span> <?php echo e($familia->abastecimento_agua); ?>

                    </div>
                    <div class="col-sm-4">
                      <span class="font-bold col-blue-grey">Destino do Lixo:</span> <?php echo e($familia->destino_lixo); ?><br />
                      <span class="font-bold col-blue-grey">Destino das Fezes e Urina:</span> <?php echo e($familia->destino_fezes_urina); ?>

                    </div>
                  </div>
                  <div class="row clearfix">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
                      <div class="table-responsive">
                          <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                              <thead>
                                  <tr>
                                      <th>Nome</th>
                                      <th>Idade</th>
                                      <th>Sexo</th>
                                      <th>Ocupação</th>
                                      <th>Observações</th>
                                      <th>Doenças / Condições</th>
                                  </tr>
                              </thead>
                              <tfoot>
                                  <tr>
                                    <th>Nome</th>
                                    <th>Idade</th>
                                    <th>Sexo</th>
                                    <th>Ocupação</th>
                                    <th>Observações</th>
                                    <th>Doenças / Condições</th>
                                  </tr>
                              </tfoot>
                              <tbody>
                                <?php $__currentLoopData = $familia->membros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                    <td><a href="<?php echo e(route('pacientes.show', $membro->id)); ?>"><?php echo e($membro->nome_completo); ?></a></td>
                                    <td><?php echo e(Date::parse($membro->data_nascimento)->age); ?></td>
                                    <td><?php echo e($membro->sexo); ?></td>
                                    <td><?php echo e($membro->ocupacao); ?></td>
                                    <td><?php echo e($membro->alfabetizado . $membro->frequenta_escola . $membro->chefe_familia); ?></td>
                                    <td>
                                      <?php $__currentLoopData = $membro->condicoes_referidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="label bg-grey"><?php echo e($valor->sigla . ' - ' . $valor->nome); ?></span>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                  </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                          </table>
                      </div>

                  </div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                      <ul class="list-unstyled" id="botoes">
                        <li>
                          <br />
                          <button type="button" id="baixarProntuario" class="btn btn-success btn-block btn-lg waves-effect">
                              <i class="material-icons">file_download</i>
                              <span>Baixar Prontuário</span>
                          </button>
                        </li>
                        <li>
                          <br />
                          <button type="button" class="btn bg-teal btn-block btn-lg waves-effect" data-toggle="modal" data-target="#adicionarRegistro">
                              <i class="material-icons">add</i>
                              <span>Adicionar Um Novo Registro</span>
                          </button>
                        </li>
                        <li>
                          <br />
                          <button type="button" class="btn bg-green btn-block btn-lg waves-effect" data-toggle="modal" data-target="#adicionarAgenda">
                              <i class="material-icons">date_range</i>
                              <span>Agendar Visita</span>
                          </button>
                        </li>
                        <li>
                          <br />
                          <a type="button" class="btn bg-blue btn-block btn-lg waves-effect" href="<?php echo e(route('pacientes.adicionar')); ?>">
                              <i class="material-icons">date_range</i>
                              <span>Acrescentar Membro</span>
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                <div class="row clearfix">
                  <?php $__env->startComponent('comments::components.comments', ['model' => $familia]); ?>
                  <?php echo $__env->renderComponent(); ?>
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="adicionarAgenda" tabindex="-1" role="dialog">
      <div class="modal-dialog modal-lg" role="document">
          <div class="modal-content">
              <div class="modal-header">
                  <h4 class="modal-title" id="adicionarAgendaLabel">Agendar Visita: <?php echo e($familia->familia); ?></h4>
              </div>
              <form method="POST" action="<?php echo e(route('agendamentos.store')); ?>">
                <div class="modal-body">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="paciente_id" value="<?php echo e($familia->id); ?>">
                  <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                  <div class="row clearfix">
                    <div class="col-sm-6">
                      <div class="form-group">
                          <div class="form-line">
                              <input type="text" class="datetimepicker form-control" name="data_inicio" id="data_inicio" placeholder="Selecione Data e Hora para a visita...">
                          </div>
                      </div>
                    </div>
                  </div>
                  <div class="row clearfix">
                    <div class="col-sm-12">
                      <div class="form-group">
                          <div class="form-line">
                              <textarea rows="3" id="observacao" class="form-control no-resize" name="observacao" placeholder="Digite sua observação..."></textarea>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-link waves-effect">SALVAR</button>
                    <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">FECHAR</button>
                </div>
              </form>
          </div>
      </div>
  </div>

</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('includeJs'); ?>
  <?php echo $__env->make('layouts.includes.inputMask', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.select', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.modals', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.summernote', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.datetimepicker', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.dialogs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.includes.pdf', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
$(function () {
    $('.summernote').summernote({
      tabsize: 2,
      lang: 'pt-BR',
      height: 180
    });
    $('.datetimepicker').bootstrapMaterialDatePicker({
        format: 'dddd DD MMMM YYYY HH:mm',
        weekStart: 0,
        lang: 'pt-BR',
        time: true,
    });
  });
  $('#baixarProntuario').click(function () {
    $('#botoes').hide();
    swal({
        title: "Aguarde",
        text: "Estamos criando seu PDF, pode levar alguns segundos =)",
        type: "warning"
      });
    html2canvas(document.querySelector("#prontuarioFamilia")).then(function(canvas) {
        var doc = new jsPDF();
        var specialElementHandlers = {
            '#editor': function (element, renderer) {
                return true;
            }
        };
        doc.addImage(canvas, 'PNG', 10, 10, 190, 114);
        doc.save('thisMotion.pdf');
        $('#botoes').show();
        swal({
            title: "Tudo bem",
            text: "PDF gerado com sucesso",
            type: "success"
          });
    });
  });
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>