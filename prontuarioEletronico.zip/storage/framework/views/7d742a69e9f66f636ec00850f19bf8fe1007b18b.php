<!-- advancedForms  -->
<link href="<?php echo e(asset('plugins/summernote/summernote.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('plugins/summernote/summernote.js')); ?>"></script>

<!--<script src="<?php echo e(asset('plugins/advanced-form-elements.js')); ?>"></script>
 advancedForms -->
