<!-- lista-de-contratos -->
<link href="<?php echo e(asset('plugins/selectize-js/selectize.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('plugins/selectize-js/selectize.min.js')); ?>"></script>
<!-- fim lista-de-contratos -->
