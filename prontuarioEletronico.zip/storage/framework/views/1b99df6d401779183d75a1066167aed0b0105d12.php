<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="container-fluid">
    <div class="block-header">

    </div>
    <div class="row">
      <painel titulo='PACIENTES'>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pacientes-create')): ?>
          <a href="<?php echo e(route('pacientes.adicionar')); ?>" class="btn btn-primary waves-effect">Adicionar Paciente</a>
        <!--  <a href="<?php echo e(route('familias.index')); ?>" class="btn bg-teal waves-effect">Ver Famílias Cadastradas</a> -->
        <?php endif; ?>

        <div class="row clearfix">
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nome</th>
                            <th>Familia - SIAB</th>
                            <th>Idade</th>
                            <th>Último Atendimento</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                          <th>#</th>
                          <th>Nome</th>
                          <th>Familia - SIAB</th>
                          <th>Idade</th>
                          <th>Último Atendimento</th>
                          <th>Ações</th>
                        </tr>
                    </tfoot>
                    <tbody>
                      <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($paciente->id); ?></td>
                          <td><a href="<?php echo e(route('pacientes.show', $paciente->id)); ?>"><?php echo e($paciente->nome_completo); ?></a></td>
                          <td>
                            <?php if($paciente->getOriginal('familia_id') != null): ?>
                              <a href="<?php echo e(route('familias.show', $paciente->getOriginal('familia_id'))); ?>"><?php echo e($paciente->familia_id); ?></a>
                            <?php else: ?>
                              <?php echo e($paciente->familia_id); ?>

                            <?php endif; ?>
                          </td>
                          <td><?php echo e(Date::parse($paciente->data_nascimento)->age .' anos'); ?></td>
                          <td><?php echo e(Date::parse($paciente->ultimo_atendimento)->format('j \d\e F\, Y')); ?><br />
                            <small><timeago datetime="<?php echo e($paciente->ultimo_atendimento); ?>" locale="pt-BR"></timeago></small>
                          </td>
                          <td>
                            <form action="<?php echo e(route('pacientes.destroy', $paciente->id)); ?>" method="post">
                              <a title="Editar" class="btn btn-primary waves-effect" href="<?php echo e(route('pacientes.edit', $paciente->id)); ?>">
                                <i class="material-icons">mode_edit</i>
                              </a>
                              <input type="hidden" name="_method" value="DELETE" />
                              <?php echo csrf_field(); ?>

                              <button type="submit" title="Excluir" class="btn btn-danger waves-effect">
                                <i class="material-icons">delete</i>
                              </button>
                            </form>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
          </div>
        </div>


    </painel>
		</div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('includeJs'); ?>
  <?php echo $__env->make('layouts.includes.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>