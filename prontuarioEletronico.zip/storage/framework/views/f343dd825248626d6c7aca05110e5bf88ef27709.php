<?php if(auth()->guard()->check()): ?>
    <?php if($model->comments->count() < 1): ?>
        <div class="card">
          <div class="header">
              <h2>
                  Nenhum atendimento foi feito ainda. <small>Mensagem do sistema</small>
              </h2>
          </div>
        </div>
    <?php endif; ?>
    
    <ul class="list-unstyled">
        <?php $__currentLoopData = $model->comments->where('parent', null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('comments::_comment', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <?php echo $__env->make('comments::_form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
    <?php if($model->comments->count() < 1): ?>
      <div class="card">
        <div class="header">
            <h2>
                Nenhum atendimento foi feito ainda. <small>Mensagem do sistema</small>
            </h2>
        </div>
      </div>
    <?php endif; ?>

    <ul class="list-unstyled">
        <?php $__currentLoopData = $model->comments->where('parent', null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('comments::_comment', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Authentication required</h5>
            <p class="card-text">You must log in to post a comment.</p>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Log in</a>
        </div>
    </div>
<?php endif; ?>
