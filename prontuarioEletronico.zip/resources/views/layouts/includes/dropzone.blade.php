<link href="{{ asset('plugins/dropzone/dropzone.css') }}" rel="stylesheet">
<script src="{{ asset('plugins/dropzone/dropzone.js') }}"></script>
