<link href="{{ asset('plugins/jquery-spinner/css/bootstrap-spinner.css') }}" rel="stylesheet">
<script src="{{ asset('plugins/jquery-spinner/js/jquery.spinner.js') }}"></script>
