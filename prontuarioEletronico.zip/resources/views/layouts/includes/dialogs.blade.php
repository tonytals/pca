<link href="{{ asset('plugins/sweetalert/sweetalert.css') }}" rel="stylesheet" />
<script src="{{ asset('plugins/sweetalert/sweetalert.min.js') }}"></script>
