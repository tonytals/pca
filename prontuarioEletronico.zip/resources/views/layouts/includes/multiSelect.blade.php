<link href="{{ asset('plugins/multi-select/css/multi-select.css') }}" rel="stylesheet">
<script src="{{ asset('plugins/multi-select/js/jquery.multi-select.js') }}"></script>
