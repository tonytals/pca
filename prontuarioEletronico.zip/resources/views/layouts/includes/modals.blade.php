<script src="{{ asset('plugins/modals.js') }}"></script>
