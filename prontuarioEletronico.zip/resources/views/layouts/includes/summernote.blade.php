<!-- advancedForms  -->
<link href="{{ asset('plugins/summernote/summernote.css') }}" rel="stylesheet">
<script src="{{ asset('plugins/summernote/summernote.js') }}"></script>

<!--<script src="{{ asset('plugins/advanced-form-elements.js') }}"></script>
 advancedForms -->
