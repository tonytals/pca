<script src="{{ asset('plugins/pdf/jspdf.min.js') }}"></script>
<script src="{{ asset('plugins/html2canvas.min.js') }}"></script>
