<div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">pesquisa</i>
        </div>
        <input type="text" placeholder="PESQUISAR...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
