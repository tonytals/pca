@extends('layouts.default')

@section('content')
<section class="content">
      <div class="container-fluid">
          <div class="block-header">
              <h2>VOCÊ NÃO POSSUI PERMISSÃO PARA ACESSAR ESSA PÁGINA!</h2>
          </div>
      </div>
  </section>

@endsection
