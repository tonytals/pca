<h2>Arquivos de linguagem em Português do Brasil (pt-BR) para Laravel 5.7
Instalação</h2>

<h3>Download</h3>

<code>
cd resources/lang/

git clone https://github.com/esjdev/laravel-5.7-ptBR-localization ./pt-BR
</code>

<h3>Configuração</h3>

<code>
// Altere Linha 81 do arquivo config/app.php para:

'locale' => 'pt-BR',
</code>
